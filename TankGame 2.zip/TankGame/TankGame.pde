// NOAH KERGAYE | Tank Game | April 14, 2026
PImage bg;
Tank tank1;
ArrayList<Obstacle> obstacles = new ArrayList<Obstacle>();
ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
int score;
Timer obsTimer;

void setup() {
  size(500, 500);
  bg = loadImage("BG1.png");
  tank1 = new Tank();
  //obstacles.add(new Obstacle(250, 250));
  //obstacles.add(new Obstacle(25, 400));
  //obstacles.add(new Obstacle(100, 200));
  //obstacles.add(new Obstacle(400, 650));
  score=0;
  obsTimer = new Timer(1000);
  obsTimer.start();
}

void draw() {
  background(127);
  imageMode(CORNER);
  image(bg, 0, 0);
  // Add timer to distribution
  if (obsTimer.isFinished()) {
    obstacles.add(new Obstacle(-100, int(random(height))));
    obsTimer.start();
  }
  //obstacle.add(new Obstacle(250, 250));

  // displaying obstacles
  for (int i = 0; i < obstacles.size(); i++) {
    Obstacle obs = obstacles.get(i);
    obs.display();
    obs.move();
    if (obs.reachedSide()) {
      obstacles.remove(i);
    }
  }

  for (int i = 0; i < projectiles.size(); i++) {
    Projectile p = projectiles.get(i);
    p.display();
    p.move();
  }
  tank1.display();
  scorepanel();
}

void scorepanel() {
  fill(127, 127);
  rectMode(CENTER);
  rect(width/2, 30, width, 60);
  fill(255);
  textSize(30);
  textAlign(CENTER);
  text("Score:" + score, width/2, 50);
}

void keyPressed() {
  if (key == 'w' || key == 'W') {
    tank1.move('w');
  } else if (key == 's' || key == 'S') {
    tank1.move('s');
  } else if (key == 'a' || key == 'A') {
    tank1.move('a');
  } else if (key == 'd' || key == 'D') {
    tank1.move('d');
  }
}

void mousePressed() {
  projectiles.add(new Projectile(int(tank1.x), int(tank1.y)));
}
